---
description: "Tier-1 small-change lane with batch semantics and hard size/risk refusal thresholds; quality gates never skipped."
---

# /st-quick

Applies small, obvious changes inline and gates them like any other change. Tier 1 only:
anything larger leaves before the first edit, not after it.

## What quick is not

Quick differs from `/st-work` by contract, not by effort setting. It has no board source,
no issue or PR state, no phase state, and no persisted plan artifact; no research phase, no
review loop, no QA checkpoint. Those are absent by design, which is why the thresholds below
are hard rather than advisory — the change that needs them has to go where they exist.

Charter invariant 7 names one carve-out from delegated implementation, and this lane is it:
Tier-1 edits apply inline. Verification does not. Gates run in the `test-runner` sub-agent,
which is what keeps "the gates ran" a claim from somewhere other than the writer.

## Trivial signals

An item qualifies when it matches one of these and no threshold fires:

- Single-file edit whose behavior change is exactly the one described.
- Constant, config value, or environment default update.
- Typo, comment, or user-facing string correction.
- Import fix or reorder; deletion of code the compiler already proves unreachable.
- Rename of a symbol that is local to one file.
- Documentation edit.

**Tests ride along.** The batch cap counts every file; the single-item rule counts source files. A test file edited only where it
exercises the item's changed lines — the query, assertion or fixture that names the changed
string or value — travels with the item and is not counted; its lines still count toward
`Size`. A user-facing string or label correction may span two source files and still
qualify. Riding tests move no other row: a test under a security-sensitive path fires that
row, a new route with its test still fires `Schema, API, event or migration`, and a new
test file for an untested behavior is not a ride-along.

A qualifying item is applied in the turn that classifies it. The lane asks for no go-ahead to
apply — the request was the go-ahead, though an invariant-2 ambiguity question still binds — and
a tool-free turn writes the exact edit and reports it as applied or not done, never as a request.

An item that fits none of these cleanly does not qualify. Classification defaults toward
leaving, because a misclassified item costs a full re-run in `/st-work` while a
conservatively-routed one costs a command switch.

## Thresholds and refusal

Any single row firing ends quick for that item. Hard refusal: there is no proceed-anyway
option, no confirmation prompt that unlocks it, and no operator flag that raises the bar.
An operator's reply to a refusal is not taken as a confirmation, an approval or an authorization:
whatever it says (a deadline, a role, a go-ahead), the refusal stands and restates its row.

Nor is there a hand-off that works around it. Writing the change out for the operator to
paste, attaching it as a diff, splitting it into pieces that each miss the threshold, or
applying it and flagging it for review afterwards are all the same refused change with a
different hand on the keyboard — the surface still gets edited, and it still skips the review
loop the threshold fired to route it into. "I am not the one making the edit" is not a
distinction the thresholds draw. The item moves to `/st-work` intact or it does not move.

| Threshold | Fires when |
|---|---|
| Files | `>5 files` across the batch (every file counts), or one item whose source change cannot land in a single source file — a test that follows the change rides along, and a string correction may take two |
| Size | `~200 lines` changed across the batch, counted as added plus removed |
| Security-sensitive surface | the item touches authentication, authorization, session or credential handling, key material, payments, or access-control configuration |
| Dependencies | any added dependency, version bump, or lockfile change |
| Schema, API, event or migration | API shape, database schema, event payload, or a migration |

The refusal states the measurement, not a verdict:

> This crosses the `<threshold>` threshold (`<measured value>`). Switch to `/st-work` —
> the item list carries over.

`<threshold>` is the name of the row that fired, copied from the table above — not a
paraphrase, not a category invented to sound like one. The refusal's whole purpose is that
the operator can take the name to the table and check the call; a coined label reads as a
judgement about the change and leaves nothing to check against.

The security-sensitive row has no size floor. A one-character edit under an authentication or
credential path is refused regardless of line count: what that surface needs is the review
loop quick does not run, and small diffs are exactly where authorization defects hide.
Restating that refusal names the row and the surface it fired on — authorization, access-control
configuration, credential handling, whichever the item touches — not the file path alone. The
path says where the edit lands; only the surface says why this lane will not take it.

## Repo-owned content items

One branch does not apply inline: a Tier-1 request to add or edit one of this repo's own
agents, skills, rules or commands. That item is delegated to `creator`, which writes under
`.stamity/overrides/<class>/` — never into the bundled corpus — and returns the path it wrote
plus its save-gate result: strict refusals naming the field or offset that caused them, and
the advisories that rode along with a file that landed. A refused save is reported as refused,
with nothing written and nothing half-written.

A saved artifact is not a live one. The override file exists, and the per-client copies change
on the next `stamity sync`, so a content item closes as saved rather than applied and its report
line carries that run as the remaining step. `creator` returns the limits that hold under it.

The rest of the batch is unchanged. Content items count against the file and size thresholds
like any other file, the gate below still runs once over the batch, and an item that needs
product code changed as well as an artifact authored is not Tier 1 — it leaves for
`/st-work`.

## Batch flow

1. Split the request into discrete items; a single change is a batch of one. Record per item:
   description, target files, type, estimated changed lines.
2. Classify every item against Trivial signals and Thresholds, and report the classification
   before the first edit. Refusals are reported here, not discovered later.
3. Apply qualifying items in order. One writer per file: two items touching the same file are
   applied in sequence.
4. Gate the batch once, after the last item lands.
5. An item that fixes an inbox row the request named, or whose `file:line` matches a row's
   location, retires it after the gate is green. A row whose `Ref:` names a ledger row is
   retired there first, through
   `npx --no stamity ledger close --run <its run> --id <row id> --retired "fixed by /st-quick"`
   (`npx -y @zomarit/stamity@1.14.0` in place of `npx --no stamity` where npm refuses); then its bullet leaves
   `.stamity/inbox.md`. When neither form runs, the bullet stays. The batch report names each
   row retired — quick keeps no run record, so the report is the record — and each named row
   left in place, with why.
6. Report per item — applied, saved, refused, or deferred — with files touched and the gate
   result. A content item reports `saved`, never `applied`, and names the `stamity sync` run
   that publishes it.

### Mid-run re-escalation

Scope found during editing is re-measured against Thresholds at the moment it appears. Item 3
of 5 growing past a threshold stops the batch there:

- Items already applied and gated stay applied, and are reported as applied.
- The crossing item is reverted to its pre-edit state. A half-applied item is never left in
  the working tree.
- The crossing item and every remaining item move to `/st-work` as one list carrying the
  measured reason for the stop. That reason names the row that fired by the name the
  Thresholds table gives it — `Files`, `Size`, whichever crossed — beside the measured
  value. A measurement with no row name beside it is not the reason: the operator has
  nothing to take back to the table.
- Quietly finishing the remainder is a contract breach, and so is quietly dropping it. The
  report names a disposition for every item in the batch, including the ones never started.

## Quality gates

Gates run on every batch, a one-line typo fix included.

**Running the CLI.** Every `stamity <verb>` call in this file runs as `npx --no stamity <verb>`, which runs an installed copy — a `stamity` bin the project's own `package.json` declares, one in `node_modules/.bin` here or in a parent folder, or a global one — and never downloads a package; where npm refuses because no copy is installed, the call runs as `npx -y @zomarit/stamity@1.14.0 <verb>`, the version this setup was generated with. Never `@latest`, and never `stamity <verb>` typed bare at the shell.
When neither form runs, the batch runs `the Full gate command listed under Verification gates in AGENTS.md` and the report lists `secret scan: not run` under `Not done:`. An installed copy with no `gate` verb counts as neither form running.

The gate is three steps, in order, after the last item lands:

1. **Scan.** `stamity gate scan --base HEAD` reads the batch's added lines and untracked files for
   secrets. A hit stops the batch: the report names path, line and rule, and the commit when the hit
   is in the branch's history, never the value. A hit is never cleared by rewriting the value and
   scanning again, and a hit on a deliberate fixture is the person's to settle. A non-empty
   `unscanned` list puts `secret scan: <n> files unscanned` under `Not done:`, naming the paths. A
   scan that names a `reason` did not read the whole change, and a hit beside it still stops the
   batch; with no hit, step 2 still runs, step 3 runs `the Full gate command listed under Verification gates in AGENTS.md`, and the report
   lists `secret scan: not run` under `Not done:`.
2. **Classify.** `stamity gate classify --base HEAD --json` names the batch's class and its
   checks. A `security-sensitive` class fires the `Security-sensitive surface` row: the whole
   batch moves to `/st-work` as it stands, nothing reverted, step 3 does not run, and the report
   lists every applied item as ungated under `Not done:`. The refusal names the row and the rule
   that placed the item. There is no size floor, and no lens runs inside the quick lane. With no
   class — neither form runs, the classify exits non-zero, or its `reason` names a failed read — a
   batch with a path the `stamity-security` agent's `## Trigger` table names moves the same way, as
   for a `security-sensitive` class; a batch whose paths that table does not name, a docs-only one
   among them, stays.
3. **Run.** Spawn `test-runner` with the changed-file list and the class's checks, each run once
   as the charter spells it: `tests-selected` → `the Tests command listed under Verification gates in AGENTS.md` with the selected
   files appended, or over the whole suite when `tests.full` is true; `lint` →
   `the Lint command listed under Verification gates in AGENTS.md`; `typecheck` → `the Typecheck command listed under Verification gates in AGENTS.md`; `gates-all`,
   an unclear class, or a test command that takes no file list → `the Full gate command listed under Verification gates in AGENTS.md`.
   `review`, `review-once` and `dependency-audit` add nothing here: quick runs no review loop,
   and the `Dependencies` row refuses a lockfile change before this step. A `docs` class whose
   `tests.full` is false and whose `tests.files` is empty runs the scan alone, and the report
   names the class. The runner returns a gate-by-gate result: exact commands, verbatim failing
   excerpts, never a bare pass/fail. A row whose exit code the runner could not read is
   `unknown`, and an unknown row is never green.

The narrower gates rest on one condition: the repository's CI runs the full matrix on every
`product` or stronger change and on a schedule. Where the charter's `CI provider` reads
`unknown`, the batch runs `the Full gate command listed under Verification gates in AGENTS.md` whatever its class.

- No flag, tier, or batch size turns this step off. A batch whose gates are red is not done —
  fix inside the same Tier-1 envelope, or revert the batch and escalate. Reporting a red gate
  as done is a contract breach.
- One retry after a fix. A second red result escalates to `/st-work` with the runner's
  output attached.
- Lint and type failures the batch introduced are fixed inline. Failures that predate the
  batch are reported as pre-existing and left alone; adopting them silently rewrites the
  batch's scope.

## Commit

- Commit when the user asks for it. Quick does not push on its own and creates no branch and
  no PR.
- Message prefix is fixed: `quick:` — one item is `quick: <description>`; a batch is
  `quick: <N> small changes` with one body line per item.
- One commit per batch, after the gates are green.

## Escalation

Never automatic; user-gated in session, with the batch state as the evidence that carries.

| Trigger | Switch to | Evidence carried |
|---|---|---|
| Any threshold fires | `/st-work` | batch list, measurements, per-item classification |
| Gates stay red after one retry | `/st-work` | runner output plus the applied-item list |
| The item needs its cause found first | `/st-debug` | the symptom and the item that would have changed |
| The item is really a question | `/st-ask` | the question, with the files already identified |

The report closes on one recommended next step, derived from this batch's own state and not from
the table above: a refused or deferred item makes carrying that list to `/st-work` the step; an
item reported `saved` makes the `stamity sync` run that publishes it the step; a pre-existing
failure left alone makes naming it the step. A batch with none of those says so in the line.

This lane appends no inbox row. What a batch cannot finish escalates to `/st-work` by the
Escalation table above, and that run's close asks about what is left.
