---
name: st-debug
description: Hypothesis-driven debugging with observation-only instrumentation and user or in-process reproduction; fixes route through the work pipeline after root cause and a failing test.
disable-model-invocation: true
---

# /st-debug

Finds what actually causes a defect, then routes the fix through `/st-work`. Fixes by
default; `--diagnose` stops after the cause is named and written up.

## Target detection

Two targets. Detect before step 1 and state the detected target in the first response.

| Symptom signal | Target | Probe |
|---|---|---|
| Failing product test, stack trace in product paths, wrong user-visible behavior | app code | `the Tests command listed under Verification gates in AGENTS.md` on the failing case; `git log -S` on the suspect symbol for the introduction window |
| Generated agent files absent, stale, or edited outside their managed block | this install | `stamity check` — environment probes plus the drift gate |
| Frontmatter or structure complaints about repo-authored content | this install | `stamity validate` |
| Manifest or ownership ledger disagreeing with what is on disk | this install | read `.stamity/manifest.json`, then `stamity check` |

There is no separate doctor verb: `stamity check` is the install probe and its exit code is
the signal — any failing probe or unclean drift exits non-zero, warnings alone exit 0.

**Running the CLI.** Every `stamity <verb>` call in this file runs as `npx --no stamity <verb>`, which runs an installed copy — a `stamity` bin the project's own `package.json` declares, one in `node_modules/.bin` here or in a parent folder, or a global one — and never downloads a package; where npm refuses because no copy is installed, the call runs as `npx -y @zomarit/stamity@1.11.0 <verb>`, the version this setup was generated with. Never `@latest`, and never `stamity <verb>` typed bare at the shell. A `not-runnable` result on both names the install as the unresolved input.

Every repo gate named here — the probe above, and the failing-test gate at step 6 — runs in a
`test-runner` spawn, never in this command's own context. The runner returns a gate-by-gate
result: the exact command, pass or fail, and the verbatim failing excerpt. Bare pass/fail is not
a result, and a fresh spawn keeps a long gate's output out of the reasoning context that ranks
the hypotheses. The runner reports and nothing else — it applies no edit and proposes no patch,
so adding it opens no second fix path.

When both targets are live (a product test fails *and* drift is reported), debug the install
first. Generated context is an input to every other hypothesis, so a stale corpus makes the
app-code round unfalsifiable.

## Loop

Nine steps. Steps 1-4 form a round and repeat while the evidence lands short; steps 5-9 run
once each.

**Run record.** The run's first mutation — a probe or gate 2's test — opens
`.stamity/runs/<run-id>/record.md`, `<run-id>` being `<UTC date>_debug-<slug>`, with
`Status: in progress`, `Plan: none — debug round` and `Invocation: <this command line, verbatim>`
among its first 15 lines, then one line per probe site as it lands and one per strip. The three
head lines are written bare at column 0, with no list marker and no bold; the resume card finds
the record by its `_debug-` segment. The close rewrites `Status:` to the exit taken and the
residue count; a stop that waits on the user leaves it in progress.

1. **Hypotheses.** From the symptom — expected, actual, reproduction path, frequency — write
   numbered hypotheses ranked by prior probability, each paired with the single observation
   that separates it from its neighbours. A hypothesis with no discriminating observation is
   not testable: rewrite it or drop it. Brief a `researcher` when the suspect surface spans
   more than two files or is unfamiliar: symptom trace, introduction window, prior learnings.
   Every `researcher` brief carries the six keys its schema requires — `objective`, `scope` with the task boundaries, `questions`,
   `output_sections`, `depth` (`quick`, `standard` or `deep`) and `tool_tier` (`codebase`, `+docs` or `+web`) — plus `handoff_to` when the consumer is not this flow.
2. **Instrumentation.** On the in-process route (step 3) this step runs only when the failing
   test alone cannot separate the hypotheses. Delegate the edit to `implementer` —
   instrumentation is a code mutation and is written where every other mutation is.
   Observation-only logging at the discriminating points, every line beginning with the tag
   `[STAMITY-DEBUG]` carrying the run record's id inside its brackets, `[STAMITY-DEBUG <run-id>]`,
   and naming its site (`[STAMITY-DEBUG <run-id>] cart/total.ts:41 applyDiscount
   entry — subtotal, coupon id`). Use the logging mechanism the project already has; add no
   dependency. Control flow, state, and error handling stay byte-identical in behavior —
   instrumentation that changes behavior invalidates the round.
   A probe keeps `the Lint command listed under Verification gates in AGENTS.md` and `the Typecheck command listed under Verification gates in AGENTS.md` green: it
   uses a form the project's linter and type checker already accept, and a probe that turns
   either red is rewritten before the round continues.
   The brief states the exception this spawn runs under, because the implementer's own
   contract mandates a unit with interfaces, a test delta and a spec delta, and observation-only
   logging produces none of the three: no unit, no interfaces, no test delta, no spec delta, and
   the changed-file list, the instrumented sites and its lint and typecheck results as the whole
   return. A brief that leaves the exception unstated promises a unit it does not carry, and the
   spawn answers it with `BLOCKED_AMBIGUITY`. The same exception covers the strip at step 8.
3. **Reproduce.** Two routes; the report decides which, and the first response names it
   with the fact that chose it.
   - **In-process** — the report states an exact input, the expected output and the actual
     output, and the charter's test gate is runnable here: neither `unknown` nor
     `not-runnable`. `implementer` writes gate 2's failing test — that input, that
     expected output, nothing else — under step 2's exception with a test delta as its
     only change; `test-runner` runs it twice. A failure for the stated reason on both
     consecutive runs is the reproduction: no stop, and no question to the user. A test
     that does not fail for the stated reason on both runs is not a reproduction, and the
     run takes the user route — never another in-process round.
   - **User** — anything else, or a defect that needs the user's environment, data,
     device, account, network, traffic or timing. Stop and wait. The user runs the
     scenario and returns the output.
   This step is not simulated, not inferred from reading the code, and not passed over
   because the cause looks obvious.
4. **Log analysis.** Order the tagged lines; state which instrumentation points did *not*
   fire, since a silent point is evidence; map every hypothesis to the lines that confirm or
   kill it; strike the killed ones. If no hypothesis survives with evidence, start another
   round with instrumentation moved — bounded by the escape valve below. On the in-process
   route the failing test's output is the evidence.
5. **Root cause.** Gate `root-cause-before-fix` (see Hard gates).
6. **Failing test.** Gate `failing-test-before-fix` (see Hard gates).
7. **Fix through the work pipeline.** The diagnosis and the failing test become the plan
   handed to `/st-work`; its Build and Prove phases apply the change and gate it. Debug
   owns no fix path of its own. This handoff is the one in-run transition that is not
   user-gated: the command fixes by default, and gating the step that performs the fix would
   leave every run stopped at its own purpose. `--diagnose` is how a run opts out, and step 8
   still runs before the switch.
8. **Instrumentation cleanup.** `implementer` strips what step 2 added; the orchestrator
   verifies the count itself. Zero residue (see Hard gates).
9. **Regression clauses.** Write what the repository shall continue to do, one clause per
   observation the defect violated — "the cart total shall continue to exclude expired
   coupons" — and point each clause at the test that holds it. Clauses with no test are
   listed as gaps in the closing report, not silently dropped.

## Hard gates

| Gate | Passes when | On failure |
|---|---|---|
| `root-cause-before-fix` | The cause is a causal chain from cited `path:line` to the observed symptom, confidence medium or better, explaining every step-4 observation including the points that stayed silent | No product-code edit. Run another round from step 1, or return `BLOCKED_FAILURE` with the surviving hypotheses ranked and the evidence each still needs |
| `failing-test-before-fix` | A test fails on the current tree for the stated cause, and its failure message names the defect rather than asserting a placeholder. The report says both in words before the fix starts — that this gate requires such a test, and whether the tree already carries one; writing the test is not a substitute for saying it | The fix does not start. A failure mode that cannot be automated records why, plus a QA row for the human checkpoint |
| Work pipeline executes the fix | The diagnosis plus the failing test are handed to `/st-work` as the plan | An edit applied inside debug is a contract breach — **product code** is what that means, the same boundary gate 1 draws: revert it and re-route. There is no private fix pipeline. Two mutations sit outside the boundary and neither is a fix: step 2's instrumentation, and gate 2's test, which has to exist as a written file to fail on the current tree |
| Zero residue | Repo-wide `[STAMITY-DEBUG]` count is 0, and every helper or import added to support instrumentation is gone | Repeat cleanup until the count is 0. A run above 0 does not report done |
| Zero residue — capture-later exception | The user agreed at step 3 to capture later, so the instrumentation stays. The agreement is recorded with its date and the sites left in place | The count is stated, never claimed as 0, and the run closes `not done: <n> instrumentation lines held under a capture-later agreement`. It is the one exit that reports residue and still closes |

A hypothesis is not a root cause, and a green test is not a root cause either: both are
consistent with a coincidence. The chain has to say why the symptom follows from the cited
lines, and what would have to be true for the chain to be wrong.

Neither gate is the operator's to waive. Certainty, a pending deploy, and an instruction to ship
anyway are inputs neither gate reads, and the report never offers the fix on the operator's call
while a gate is unmet — the unmet gate is the answer, not a preference the operator may overrule.

### No reproduction, no fix

When the user cannot reproduce — intermittent, environment-only, or the scenario is not
available to them — the loop stalls at step 3 and returns `BLOCKED_DEPENDENCY` naming exactly
what it needs: environment, data, access, or a longer capture window. That return carries one
question with it — hold the step-2 instrumentation for a capture window, or strip it now — and
declares stripping now as the default. Silence, an unattended run, and an ambiguous reply all
take the default: step 8 runs immediately. Only an explicit yes holds the instrumentation,
and then the reply names the date the window ends and the run records the agreement with the
sites left in place.

A fix written without a reproduced observation is speculation. Record the ranked hypotheses
and the observation each one still needs, and stop there.

### Zero residue on every exit path

Cleanup runs on every exit: fix shipped, `--diagnose` report, reproduction blocked, escape
valve, user abort, and escalation to another command. No exit path leaves a tagged line, a
commented-out probe, or a helper that existed only to carry one. Search the repository for
the tag before the closing report and state the resulting count in it.

**The marker check.** It runs at the run's start, at every stop that waits on the user, and at
the close:

```sh
git grep -n -E '\[STAMITY-DEBUG [0-9]{4}-[0-9]{2}-[0-9]{2}_debug-[^]]*\]'
```

Its exit code 1 means zero hits, not an error. Only a probe carries a real run id, so only a
probe matches: this text, its copies and every other document name the format with the
`<run-id>` placeholder, never with an instance. At the start, a hit whose run id has neither an
in-progress debug record nor a recorded capture-later agreement is residue from an earlier run
and is stripped before step 1; a hit under a recorded agreement is kept and its count stated.
At a stop, the count and the sites go into the stop message and the record. At the close, the
count of hits carrying this run's own id is the Zero residue gate's number.

One exception, and it is the gate table's own row: a capture-later agreement recorded with the
user holds the instrumentation in place. That run reports its count rather than zero, and the
next run over the same defect strips it first. No other path holds residue.

### `--diagnose` (report only)

Stops after gate `root-cause-before-fix`. Produces the ranked hypotheses with their verdicts, the
root cause with cited evidence and confidence, the failing test as a specification (what it asserts
and where it belongs, or the written test when step 3 took the in-process route), and the fix approach with its risk.
Steps 6 and 7 do not run. Step 8 does.

## Escape valve — three failed fixes question the architecture

A failed fix is one that reached step 7, landed, and left the symptom, brought it back, or
broke a gate that had been green. Three failed fixes on one defect end the fix loop.

The counter is **in-session**: the run record holds probes and the round's status, not fix
attempts, so it counts the fixes attempted in this conversation and nothing earlier. A new
session starts at zero, and the closing report states the count it is carrying so a user on
the fourth attempt across two sessions can see that the valve did not fire and call it
themselves.

At the third failure, stop fixing and report instead:

- the invariant the current design cannot hold, stated as a property;
- the structural reason the failure is reachable, cited to `path:line`;
- two or more structural options with their costs and their blast radius.

Route to `/st-plan` with a refactor or migration intent. A fourth attempt against the
same design is not debugging — it is the same experiment run again.

## Escalation

Never automatic below the first row: the user switches in session, and step 8 runs before any
switch. The first row is the exception, and it is step 7 — a default run hands the fix to
`/st-work` on its own, because a command that fixes by default cannot gate the step that
performs the fix. That row is listed here for the `--diagnose` run, which stops before step 7
and reaches the same transition as a switch the user makes.

| Situation | Switch to | Evidence carried |
|---|---|---|
| Cause confirmed, failing test written | `/st-work` | diagnosis plus failing test as the plan |
| Three failed fixes | `/st-plan` | hypotheses, evidence, structural options |
| Cause is one mechanical slip inside the quick thresholds | `/st-quick` | the cited line plus the failing test |
| The symptom turns out to be a question, not a defect | `/st-ask` | the symptom rewritten as the question |
| The defect arrived as review feedback on delivered work | `/st-rework` | the diagnosis as a triage input |

The closing report ends on one recommended next step, derived from this run's own state and not
from the table above: a regression clause with no test makes writing it the step; instrumentation
held under a capture-later agreement makes the strip at the window's end the step; a surviving
hypothesis makes its discriminating observation the step. None of those, and the line says so.
The line ends there: one step, no second step behind it and no "if you meant X instead" branch.
A fact that would change the step is named above the step as a fact to settle, never as a second
ending the reader has to choose between.
